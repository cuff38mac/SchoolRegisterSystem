package sample;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import sample.model.Datasource;

import java.net.URL;

public class Main extends Application {
   // public static Datasource datasource;

    @Override
    public void start(Stage primaryStage) throws Exception{
       // FXMLLoader root = new FXMLLoader(Main.class.getResource("sample.fxml"));
        URL fxmlLocation = getClass().getResource("/sample.fxml");
        FXMLLoader root = new FXMLLoader(fxmlLocation);
        // Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("sample/sample.fxml")));
               //FXMLLoader.load(Objects.requireNonNull(getClass().getResource("sample.fxml")));
       // Parent root = loader.load();
     //GridPane root = new GridPane();
    // root.setAlignment(Pos.CENTER);
    // root.setVgap(10);
    // root.setHgap(10);
        Scene scene = new Scene(root.load(), 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("University Register System");
        primaryStage.show();
    }

    @Override
    public void init() throws Exception {
        super.init();
        if(!Datasource.getInstance().open()){
            System.out.println("CAN'T CONNECT");
            Platform.exit();
        }
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        Datasource.getInstance().close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
