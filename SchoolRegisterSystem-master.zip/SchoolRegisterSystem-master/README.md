# SchoolRegisterSystem
This is a Java database program that allows you to add a student or faculty member. It also allows you to see the entire list of students and faculty members from database.
